﻿using GXPEngine;
using TiledMapParser;

internal class Save : Sprite
{
    public Save(TiledObject obj = null) : base("colors.png")
    {
        alpha = 0;
    }
}

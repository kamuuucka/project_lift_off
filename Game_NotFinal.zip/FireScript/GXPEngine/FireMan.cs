﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GXPEngine;


internal class FireMan : Player2
{
    Sprite targetSpr = new Sprite("P2.png");
    public FireMan(float x, float y, Level level) : base(x, y, level)
    {
        //this.x = x;
        //this.y = y;
        GoBack();
        AddChild(targetSpr);
        isASprite = true;
    }

    void Update()
    {
        CharacterMovement();
        if (Input.GetKeyUp(Key.A))
        {
            Mirror(false, false);
        }
        else if (Input.GetKeyUp(Key.D))
        {
            Mirror(true, false);
        }
    }
}



﻿using System;
using GXPEngine;
using TiledMapParser;

internal class Fire : Sprite
{
    public Fire(TiledObject obj = null) : base("triangle.png")
    {

    }
}

